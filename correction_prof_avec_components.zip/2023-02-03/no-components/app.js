const options = {
  data() {
    return {
      amount: 0,
      from: "",
      to: "",
      currencies: [],
      results: null,
      error: "",
    };
  },
  methods: {
    convert() {
      if (this.amount <= 0) {
        this.results = null;
        this.error = "Please enter an amount";
        return;
      }

      this.error = "";

      let query = "";

      if (this.to) {
        query = `https://api.frankfurter.app/latest?amount=${this.amount}&from=${this.from}&to=${this.to}`;
      } else {
        query = `https://api.frankfurter.app/latest?amount=${this.amount}&from=${this.from}`;
      }

      fetch(query)
        .then((response) => {
          response
            .json()
            .then((data) => {
              data.amount = new Intl.NumberFormat("fr-FR").format(data.amount);

              for (const rate in data.rates) {
                data.rates[rate] = new Intl.NumberFormat("fr-FR").format(
                  data.rates[rate]
                );
              }

              this.results = data;
            })
            .catch((e) => {
              this.results = null;
              this.error = "Please select different currencies";
              console.log(e);
            });
        })
        .catch((e) => {
          console.log(e);
        });
    },
  },
  mounted() {
    fetch("https://api.frankfurter.app/currencies")
      .then((response) => {
        response
          .json()
          .then((data) => {
            this.currencies = data;
          })
          .catch((e) => {
            console.log(e);
          });
      })
      .catch((e) => {
        console.log(e);
      });
  },
};

Vue.createApp(options).mount("#app");
