import Search from "./components/search.js";
import Results from "./components/results.js";
import Error from "./components/error.js";

const options = {
  data() {
    return {
      currencies: [],
      results: null,
      error: "",
    };
  },
  components: {
    Search: Search,
    Results: Results,
    Error: Error,
  },
  methods: {
    displayConversion({ error, results }) {
      this.results = results;
      this.error = error;
    },
  },
  mounted() {
    fetch("https://api.frankfurter.app/currencies")
      .then((response) => {
        response
          .json()
          .then((data) => {
            this.currencies = data;
          })
          .catch((e) => {
            console.log(e);
          });
      })
      .catch((e) => {
        console.log(e);
      });
  },
};

Vue.createApp(options).mount("#app");
