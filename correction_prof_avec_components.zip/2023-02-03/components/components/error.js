export default {
  template: `<div>
    <h3>🚨 Error</h3>

    {{ error }}
  </div>`,
  props: ["error"],
};
