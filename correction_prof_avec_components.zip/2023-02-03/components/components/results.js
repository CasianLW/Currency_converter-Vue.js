export default {
  template: `
    <div>
    <h3>Results</h3>
    <p v-for="value, currency in results.rates">
    {{ results.amount }} {{ results.base }} = {{ value }} {{ currency }}
  </p>
  </div>
    `,
  props: ["results"],
};
