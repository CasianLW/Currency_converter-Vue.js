export default {
  template: `
    <form @submit.prevent="convert">
    <label for="amount">Amount</label>
    <input type="number" id="amount" step="0.01" v-model="amount" />

    <label for="from">From</label>
    <select id="from" v-model="from">
          <option value="" disabled>Select a currency</option>
          <option :value="index" v-for="currency, index in currencies">
            {{ currency }}
          </option>
        </select>

    <label for="from">To</label>
    <select id="to" v-model="to">
          <option value="" disabled>Select a currency</option>
          <option :value="index" v-for="currency, index in currencies">
            {{ currency }}
          </option>
        </select>

    <button type="submit">Convert</button>
  </form>
    `,
  data() {
    return {
      amount: 1,
      from: "EUR",
      to: "USD",
    };
  },
  props: ["currencies"],
  methods: {
    convert() {
      if (this.amount <= 0) {
        this.$emit("convert", {
          error: "Please enter an amount",
          results: null,
        });
        return;
      }

      let query = "";

      if (this.to) {
        query = `https://api.frankfurter.app/latest?amount=${this.amount}&from=${this.from}&to=${this.to}`;
      } else {
        query = `https://api.frankfurter.app/latest?amount=${this.amount}&from=${this.from}`;
      }

      fetch(query)
        .then((response) => {
          response
            .json()
            .then((data) => {
              data.amount = new Intl.NumberFormat("fr-FR").format(data.amount);

              for (const rate in data.rates) {
                data.rates[rate] = new Intl.NumberFormat("fr-FR").format(
                  data.rates[rate]
                );
              }

              this.$emit("convert", { error: "", results: data });
            })
            .catch((e) => {
              this.$emit("convert", {
                error: "Please select different currencies",
                results: null,
              });
              console.log(e);
            });
        })
        .catch((e) => {
          console.log(e);
        });
    },
  },
};
